//
//  GHWGiftList.h
//  GHWSDKDemo
//
//  Created by wuyx on 16/2/25.
//  Copyright © 2016年 GHW. All rights reserved.
//

#import "WADemoNaviView.h"
#import <WASdkIntf/WASdkIntf.h>
@interface WADemoGiftListView : WADemoNaviView
-(void)getGiftList;
@end
