//
//  WADemoGiftView_.h
//  WADemo
//
//  Created by wuyx on 16/7/18.
//  Copyright © 2016年 GHW. All rights reserved.
//

#import "WADemoNaviView.h"

@interface WADemoGiftView : WADemoNaviView

@end
